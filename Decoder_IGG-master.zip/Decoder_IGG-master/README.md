﻿# Decoder_IGG
众执芯项目（中国科学院地质与地球物理研究所 技术与装备研发中心）:cRIO采集+MatLabDLL算法+前面板显示

## SW & HW
* LabVIEW 2016 + Qbus + CVT
* cRIO 9037 + NI 9203 + NI 9361 + NI 9871